#!/bin/bash

./build/test/testoyttm oydata/3d_3_5.tns oydata/dense_2_3.tns