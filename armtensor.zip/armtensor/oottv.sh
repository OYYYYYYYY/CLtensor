#!/bin/bash

./build/test/testttv tensor/4d_3_16.tns oydata/vector_3.tns